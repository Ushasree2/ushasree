const teacherForm = document.getElementById('teacher-form');
const teacherList = document.getElementById('teacher-list');

teacherForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('teacher-name').value;
    const subject = document.getElementById('teacher-subject').value;

    const response = await fetch('http://localhost:5000/api/teachers', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, subject }),
    });

    if (response.ok) {
        const teacher = await response.json();
        addTeacherToList(teacher);
    }

    teacherForm.reset();
});

function addTeacherToList(teacher) {
    const li = document.createElement('li');
    li.textContent = `${teacher.name} - Subject: ${teacher.subject}`;
    teacherList.appendChild(li);
}

// Fetch and display existing teachers
async function fetchTeachers() {
    const response = await fetch('http://localhost:5000/api/teachers');
    const teachers = await response.json();
    teachers.forEach(addTeacherToList);
}

fetchTeachers();
