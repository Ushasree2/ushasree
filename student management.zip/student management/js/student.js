const studentForm = document.getElementById('student-form');
const studentList = document.getElementById('student-list');

studentForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('student-name').value;
    const age = document.getElementById('student-age').value;
    const studentClass = document.getElementById('student-class').value;

    const response = await fetch('http://localhost:5000/api/students', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, age, studentClass }),
    });

    if (response.ok) {
        const student = await response.json();
        addStudentToList(student);
    }

    studentForm.reset();
});

function addStudentToList(student) {
    const li = document.createElement('li');
    li.textContent = `${student.name} (${student.age}) - Class: ${student.studentClass}`;
    studentList.appendChild(li);
}

// Fetch and display existing students
async function fetchStudents() {
    const response = await fetch('http://localhost:5000/api/students');
    const students = await response.json();
    students.forEach(addStudentToList);
}

fetchStudents();
