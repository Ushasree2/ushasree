
const marksForm = document.getElementById('marks-form');
const marksList = document.getElementById('marks-list');
const marksStudentSelect = document.getElementById('marks-student');
const marksTeacherSelect = document.getElementById('marks-teacher');

marksForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const studentId = marksStudentSelect.value;
    const teacherId = marksTeacherSelect.value;
    const subject = document.getElementById('marks-subject').value;
    const marks = document.getElementById('marks-score').value;

    const response = await fetch('http://localhost:5000/api/marks', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ student: studentId, teacher: teacherId, subject, marks }),
    });

    if (response.ok) {
        const marksEntry = await response.json();
        addMarksToList(marksEntry);
    }

    marksForm.reset();
});

function addMarksToList(marksEntry) {
    const li = document.createElement('li');
    li.textContent = `Student: ${marksEntry.student.name}, Teacher: ${marksEntry.teacher.name}, Subject: ${marksEntry.subject}, Marks: ${marksEntry.marks}`;
    marksList.appendChild(li);
}

async function fetchStudentsAndTeachers() {
    const [students, teachers] = await Promise.all([
        fetch('http://localhost:5000/api/students').then(res => res.json()),
        fetch('http://localhost:5000/api/teachers').then(res => res.json()),
    ]);

    students.forEach(student => {
        const option = document.createElement('option');
        option.value = student.id;
        option.textContent = student.name;
        marksStudentSelect.appendChild(option);
    });

    teachers.forEach(teacher => {
        const option = document.createElement('option');
        option.value = teacher.id;
        option.textContent = teacher.name;
        marksTeacherSelect.appendChild(option);
    });
}

// Fetch and display existing marks
async function fetchMarks() {
    const response = await fetch('http://localhost:5000/api/marks');
    const marks = await response.json();
    marks.forEach(addMarksToList);
}

fetchStudentsAndTeachers();
fetchMarks();
